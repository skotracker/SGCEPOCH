////////////////////////////////////////////////////////////////////
//DeRap: Produced from mikero's Dos Tools Dll version 4.30
//Thu May 29 00:01:01 2014 : Source 'file' date Thu May 29 00:01:01 2014
//http://dev-heaven.net/projects/list_files/mikero-pbodll
////////////////////////////////////////////////////////////////////

#define _ARMA_

//Class dayz_server : config.bin{
class CfgPatches
{
	class dayz_server
	{
		units[] = {};
		weapons[] = {};
		requiredVersion = 0.1;
		requiredAddons[] = {"dayz_code"};
	};
};
//};
